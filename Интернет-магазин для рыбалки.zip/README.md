
  # Интернет-магазин для рыбалки

  This is a code bundle for Интернет-магазин для рыбалки. The original project is available at https://www.figma.com/design/3TT22aNoopd9VjThyfwbK3/%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B5%D1%82-%D0%BC%D0%B0%D0%B3%D0%B0%D0%B7%D0%B8%D0%BD-%D0%B4%D0%BB%D1%8F-%D1%80%D1%8B%D0%B1%D0%B0%D0%BB%D0%BA%D0%B8.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  