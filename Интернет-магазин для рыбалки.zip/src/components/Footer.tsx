import { Fish, Phone, Mail, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Логотип и описание */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Fish className="h-8 w-8 text-accent" />
              <h3 className="text-2xl font-bold">МЕДВЕДЪ</h3>
            </div>
            <p className="text-primary-foreground/80 mb-4">
              Рыболовный магазин с многолетним опытом. Мы знаем всё о рыбалке 
              и поможем вам выбрать лучшее снаряжение для любого вида ловли.
            </p>
            <p className="text-sm text-primary-foreground/60">
              © 2025 МЕДВЕДЬ. Все права защищены.
            </p>
          </div>

          {/* Контакты */}
          <div>
            <h4 className="font-semibold mb-4">Контакты</h4>
            <div className="space-y-3 text-primary-foreground/80">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-accent" />
                <span>+7 (495) 123-45-67</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-accent" />
                <span>info@medved-fishing.ru</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-accent" />
                <span>Москва, ул. Рыбацкая, 123</span>
              </div>
            </div>
          </div>

          {/* Время работы */}
          <div>
            <h4 className="font-semibold mb-4">Время работы</h4>
            <div className="space-y-2 text-primary-foreground/80">
              <div>Пн-Пт: 9:00 - 19:00</div>
              <div>Сб-Вс: 10:00 - 18:00</div>
              <div className="text-accent mt-4">
                Доставка по всей России
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}