import { ShoppingCart, Fish } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface HeaderProps {
  cartItemsCount: number;
  onCartClick: () => void;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Header({ cartItemsCount, onCartClick, currentPage, onNavigate }: HeaderProps) {
  const navigation = [
    { name: "Главная", key: "home" },
    { name: "Каталог", key: "catalog" },
    { name: "О нас", key: "about" },
    { name: "Советы", key: "tips" },
    { name: "Контакты", key: "contact" }
  ];

  return (
    <header className="border-b bg-card border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div 
          className="flex items-center gap-2 cursor-pointer" 
          onClick={() => onNavigate('home')}
        >
          <Fish className="h-8 w-8 text-accent" />
          <h1 className="text-2xl font-bold text-foreground">МЕДВЕДЪ</h1>
          <span className="text-sm text-muted-foreground ml-2">Рыболовный магазин</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-6">
          {navigation.map((item) => (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              className={`transition-colors ${
                currentPage === item.key
                  ? 'text-accent font-medium'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {item.name}
            </button>
          ))}
        </nav>

        <Button 
          variant="outline" 
          onClick={onCartClick}
          className="relative border-border hover:bg-secondary"
        >
          <ShoppingCart className="h-5 w-5" />
          <span className="ml-2">Корзина</span>
          {cartItemsCount > 0 && (
            <Badge 
              variant="default" 
              className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-accent text-accent-foreground"
            >
              {cartItemsCount}
            </Badge>
          )}
        </Button>
      </div>
    </header>
  );
}