import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  const scrollToCatalog = () => {
    document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative bg-gradient-to-br from-blue-900 to-blue-700 text-white">
      <div className="absolute inset-0 bg-black opacity-20"></div>
      <div className="relative container mx-auto px-4 py-24 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Добро пожаловать в
            <span className="block text-yellow-300">МЕДВЕДЪ</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100">
            Всё для успешной рыбалки в одном месте
          </p>
          <p className="text-lg mb-12 text-blue-200 max-w-2xl mx-auto">
            Профессиональное снаряжение, надёжные снасти и всё необходимое 
            для незабываемого отдыха на воде
          </p>
          <Button 
            size="lg" 
            onClick={scrollToCatalog}
            className="bg-yellow-500 hover:bg-yellow-600 text-blue-900 font-semibold px-8 py-3"
          >
            Перейти к каталогу
          </Button>
        </div>
      </div>
      
      {/* Декоративные элементы */}
      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
}