import { Button } from "./ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  inStock: boolean;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <Card className="h-full flex flex-col border-border/50 hover:shadow-lg transition-all duration-300">
      <CardHeader className="p-0">
        <div className="aspect-square relative overflow-hidden rounded-t-lg">
          <ImageWithFallback
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform hover:scale-105"
          />
          {!product.inStock && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <Badge variant="destructive">Нет в наличии</Badge>
            </div>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 p-4">
        <div className="mb-2">
          <Badge variant="secondary" className="text-xs bg-secondary text-secondary-foreground">
            {product.category}
          </Badge>
        </div>
        <CardTitle className="mb-2 line-clamp-2 text-foreground">{product.name}</CardTitle>
        <p className="text-sm text-muted-foreground line-clamp-3">{product.description}</p>
      </CardContent>
      
      <CardFooter className="p-4 pt-0 flex items-center justify-between">
        <div className="text-xl font-bold text-accent">
          {product.price.toLocaleString('ru-RU')} ₽
        </div>
        <Button 
          onClick={() => onAddToCart(product)}
          disabled={!product.inStock}
          size="sm"
          className="bg-primary hover:bg-primary/90 disabled:opacity-50"
        >
          В корзину
        </Button>
      </CardFooter>
    </Card>
  );
}