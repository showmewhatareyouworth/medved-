import { ProductCatalog } from "../ProductCatalog";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  inStock: boolean;
}

interface CatalogPageProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
}

export function CatalogPage({ products, onAddToCart }: CatalogPageProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Заголовок страницы */}
      <section className="bg-secondary/20 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4 text-foreground">Каталог товаров</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Широкий ассортимент качественного рыболовного снаряжения для профессионалов и любителей
          </p>
        </div>
      </section>

      {/* Каталог товаров */}
      <ProductCatalog products={products} onAddToCart={onAddToCart} />
    </div>
  );
}