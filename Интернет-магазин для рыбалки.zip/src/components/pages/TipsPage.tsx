import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { 
  Fish, 
  Target, 
  Clock, 
  Cloud, 
  Thermometer, 
  Moon, 
  Sun,
  BookOpen,
  TrendingUp
} from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

export function TipsPage() {
  const basicTips = [
    {
      icon: <Clock className="h-6 w-6 text-accent" />,
      title: "Лучшее время для рыбалки",
      content: "Наиболее активное время - раннее утро (4-8 часов) и вечер (18-22 часа). В пасмурную погоду рыба может клевать весь день.",
      difficulty: "Начинающий"
    },
    {
      icon: <Cloud className="h-6 w-6 text-accent" />,
      title: "Влияние погоды",
      content: "Стабильная погода без резких перепадов давления благоприятна для клёва. Небольшой дождь часто активизирует рыбу.",
      difficulty: "Начинающий"
    },
    {
      icon: <Target className="h-6 w-6 text-accent" />,
      title: "Выбор места",
      content: "Ищите места с укрытиями: коряги, камни, заросли. Рыба любит границы - места перехода глубин, течений.",
      difficulty: "Начинающий"
    },
    {
      icon: <Fish className="h-6 w-6 text-accent" />,
      title: "Прикормка и насадка",
      content: "Используйте свежую наживку. Прикормка должна соответствовать насадке по запаху и составу.",
      difficulty: "Начинающий"
    }
  ];

  const advancedTips = [
    {
      icon: <Thermometer className="h-6 w-6 text-accent" />,
      title: "Температурные слои",
      content: "В жару рыба уходит в более прохладные глубокие слои. Используйте эхолот для поиска термоклина.",
      difficulty: "Продвинутый"
    },
    {
      icon: <Moon className="h-6 w-6 text-accent" />,
      title: "Лунные фазы",
      content: "Новолуние и полнолуние влияют на активность рыбы. Планируйте рыбалку с учётом лунного календаря.",
      difficulty: "Продвинутый"
    },
    {
      icon: <TrendingUp className="h-6 w-6 text-accent" />,
      title: "Анализ поклёвок",
      content: "Ведите дневник рыбалки: время, погода, приманки, результат. Это поможет выявить закономерности.",
      difficulty: "Продвинутый"
    },
    {
      icon: <Sun className="h-6 w-6 text-accent" />,
      title: "Работа с тенью",
      content: "В солнечную погоду рыба предпочитает тенистые места. Ловите под мостами, нависающими деревьями.",
      difficulty: "Продвинутый"
    }
  ];

  const seasonalTips = {
    spring: [
      "Весной рыба активизируется после зимы, но осторожна",
      "Используйте мелкие приманки натуральных цветов",
      "Лучшие места - прогреваемые мелководья",
      "Время клёва сдвигается ближе к полудню"
    ],
    summer: [
      "Ранние утренние и поздние вечерние часы - оптимальное время",
      "Рыба держится в глубоких ямах и под укрытиями",
      "Используйте живые насадки и ароматную прикормку",
      "Не забывайте про ночную рыбалку"
    ],
    autumn: [
      "Рыба активно кормится перед зимой",
      "Увеличивайте размер приманок и порции прикормки",
      "Хорошо работают животные насадки",
      "Клёв может продолжаться весь день"
    ],
    winter: [
      "Зимняя рыбалка требует специального снаряжения",
      "Ищите рыбу в глубоких местах с медленным течением",
      "Используйте мелкие приманки и деликатную снасть",
      "Безопасность на льду - приоритет номер один"
    ]
  };

  const techniques = [
    {
      name: "Спиннинговая ловля",
      description: "Активный способ ловли хищной рыбы с использованием искусственных приманок",
      tips: [
        "Меняйте скорость и характер проводки",
        "Используйте разные типы приманок",
        "Обращайте внимание на структуру дна",
        "Не забывайте про паузы в проводке"
      ]
    },
    {
      name: "Поплавочная ловля",
      description: "Классический способ ловли с использованием поплавка и живых насадок",
      tips: [
        "Правильно настройте огрузку поплавка",
        "Используйте качественные крючки",
        "Регулярно подбрасывайте прикормку",
        "Следите за поведением поплавка"
      ]
    },
    {
      name: "Фидерная ловля",
      description: "Донная ловля с использованием кормушки и чувствительной вершинки",
      tips: [
        "Точно определите рабочую дистанцию",
        "Используйте правильную консистенцию прикормки",
        "Меняйте поводки и крючки под условия",
        "Следите за сигнализацией поклёвки"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Заголовок */}
      <section className="bg-gradient-to-br from-primary/90 to-accent/20 text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Советы рыболовам</h1>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            Практические советы и секреты успешной рыбалки от экспертов магазина МЕДВЕДЪ
          </p>
        </div>
      </section>

      {/* Основные советы */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="basic" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Базовые советы
              </TabsTrigger>
              <TabsTrigger value="advanced" className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Продвинутые техники
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="basic">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {basicTips.map((tip, index) => (
                  <Card key={index} className="border-border/50 hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        {tip.icon}
                        <CardTitle className="text-lg">{tip.title}</CardTitle>
                      </div>
                      <Badge variant="secondary" className="w-fit">
                        {tip.difficulty}
                      </Badge>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">{tip.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="advanced">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {advancedTips.map((tip, index) => (
                  <Card key={index} className="border-border/50 hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        {tip.icon}
                        <CardTitle className="text-lg">{tip.title}</CardTitle>
                      </div>
                      <Badge variant="secondary" className="w-fit bg-accent/20 text-accent">
                        {tip.difficulty}
                      </Badge>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">{tip.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Сезонные советы */}
      <section className="py-16 bg-secondary/20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Рыбалка по сезонам</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.entries(seasonalTips).map(([season, tips], index) => {
              const seasonNames = {
                spring: "Весна",
                summer: "Лето", 
                autumn: "Осень",
                winter: "Зима"
              };
              
              return (
                <Card key={index} className="border-border/50">
                  <CardHeader>
                    <CardTitle className="text-center text-accent">
                      {seasonNames[season as keyof typeof seasonNames]}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {tips.map((tip, tipIndex) => (
                        <li key={tipIndex} className="text-sm text-muted-foreground flex items-start gap-2">
                          <span className="text-accent mt-1">•</span>
                          {tip}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Техники ловли */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-12">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-foreground">Основные техники ловли</h2>
              <p className="text-muted-foreground mb-6">
                Изучите различные техники рыбалки, чтобы адаптироваться к любым условиям 
                и повысить свои шансы на успешный улов.
              </p>
            </div>
            <div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1680529642520-5897a7e9707b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwdGlwcyUyMHRlY2huaXF1ZXN8ZW58MXx8fHwxNzU4MjgyNjA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Техники рыбалки"
                className="w-full h-64 object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {techniques.map((technique, index) => (
              <Card key={index} className="border-border/50 hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-accent">{technique.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{technique.description}</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {technique.tips.map((tip, tipIndex) => (
                      <li key={tipIndex} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="text-accent mt-1">•</span>
                        {tip}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Призыв к действию */}
      <section className="py-16 bg-muted/10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4 text-foreground">Нужна персональная консультация?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Наши эксперты помогут выбрать снаряжение и дадут советы специально для ваших условий ловли
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Связаться с экспертом
          </Button>
        </div>
      </section>
    </div>
  );
}