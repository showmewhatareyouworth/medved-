import { Hero } from "../Hero";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Fish, Star, Shield, Truck } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const features = [
    {
      icon: <Fish className="h-8 w-8 text-accent" />,
      title: "Профессиональное снаряжение",
      description: "Только качественные товары от проверенных производителей"
    },
    {
      icon: <Star className="h-8 w-8 text-accent" />,
      title: "Экспертные советы",
      description: "Наши специалисты помогут выбрать лучшее для вашей рыбалки"
    },
    {
      icon: <Shield className="h-8 w-8 text-accent" />,
      title: "Гарантия качества",
      description: "Официальная гарантия на все товары от 1 года"
    },
    {
      icon: <Truck className="h-8 w-8 text-accent" />,
      title: "Доставка по России",
      description: "Быстрая и надёжная доставка в любую точку страны"
    }
  ];

  const popularCategories = [
    { name: "Удилища", count: 156, image: "https://images.unsplash.com/photo-1572726243931-884b05e4a198" },
    { name: "Катушки", count: 89, image: "https://images.unsplash.com/photo-1661944499262-8f19514ec416" },
    { name: "Приманки", count: 234, image: "https://images.unsplash.com/photo-1586920917141-71ffe0798441" },
    { name: "Аксессуары", count: 178, image: "https://images.unsplash.com/photo-1643636372526-7d687fb202a7" }
  ];

  return (
    <div>
      {/* Обновленный Hero с новой цветовой схемой */}
      <section className="relative bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative container mx-auto px-4 py-24 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Добро пожаловать в
              <span className="block text-accent">МЕДВЕДЪ</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-primary-foreground/90">
              Всё для успешной рыбалки в одном месте
            </p>
            <p className="text-lg mb-12 text-primary-foreground/80 max-w-2xl mx-auto">
              Профессиональное снаряжение, надёжные снасти и всё необходимое 
              для незабываемого отдыха на воде
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => onNavigate('catalog')}
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                Перейти к каталогу
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => onNavigate('tips')}
                className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
              >
                Советы рыболовам
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-background to-transparent"></div>
      </section>

      {/* Наши преимущества */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Почему выбирают нас</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center border-border/50 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Популярные категории */}
      <section className="py-16 bg-secondary/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Популярные категории</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularCategories.map((category, index) => (
              <Card 
                key={index} 
                className="cursor-pointer hover:shadow-lg transition-all duration-300 border-border/50 hover:border-accent/50"
                onClick={() => onNavigate('catalog')}
              >
                <div className="aspect-square relative overflow-hidden rounded-t-lg">
                  <ImageWithFallback
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover transition-transform hover:scale-105"
                  />
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-foreground">{category.name}</h3>
                    <Badge variant="secondary" className="bg-secondary text-secondary-foreground">
                      {category.count}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Призыв к действию */}
      <section className="py-16 bg-muted/20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4 text-foreground">Готовы к рыбалке?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Наши эксперты помогут подобрать идеальное снаряжение для любого вида ловли
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => onNavigate('catalog')}
              className="bg-primary hover:bg-primary/90"
            >
              Посмотреть каталог
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={() => onNavigate('contact')}
              className="border-primary text-primary hover:bg-primary/10"
            >
              Связаться с нами
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}