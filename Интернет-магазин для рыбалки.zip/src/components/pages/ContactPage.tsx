import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Car,
  MessageCircle,
  Send
} from "lucide-react";
import { toast } from "sonner@2.0.3";

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast.error("Пожалуйста, заполните все обязательные поля");
      return;
    }

    toast.success("Сообщение отправлено! Мы свяжемся с вами в ближайшее время.");
    setFormData({ name: "", email: "", phone: "", subject: "", message: "" });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const contactInfo = [
    {
      icon: <MapPin className="h-6 w-6 text-accent" />,
      title: "Адрес магазина",
      details: ["Москва, ул. Рыбацкая, 123", "ТЦ \"Рыболов\", 2 этаж"]
    },
    {
      icon: <Phone className="h-6 w-6 text-accent" />,
      title: "Телефоны",
      details: ["+7 (495) 123-45-67", "+7 (495) 765-43-21"]
    },
    {
      icon: <Mail className="h-6 w-6 text-accent" />,
      title: "Email",
      details: ["info@medved-fishing.ru", "support@medved-fishing.ru"]
    },
    {
      icon: <Clock className="h-6 w-6 text-accent" />,
      title: "Время работы",
      details: ["Пн-Пт: 9:00 - 19:00", "Сб-Вс: 10:00 - 18:00"]
    }
  ];

  const services = [
    {
      icon: <Car className="h-8 w-8 text-accent" />,
      title: "Доставка",
      description: "Доставляем по Москве и области в день заказа. По России - от 2 дней."
    },
    {
      icon: <MessageCircle className="h-8 w-8 text-accent" />,
      title: "Консультации",
      description: "Профессиональные консультации по выбору снаряжения для любого вида рыбалки."
    },
    {
      icon: <Send className="h-8 w-8 text-accent" />,
      title: "Гарантия",
      description: "Официальная гарантия на все товары. Обмен и возврат в течение 14 дней."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Заголовок */}
      <section className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Контакты</h1>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            Свяжитесь с нами любым удобным способом. Мы всегда готовы помочь!
          </p>
        </div>
      </section>

      {/* Контактная информация */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {contactInfo.map((info, index) => (
              <Card key={index} className="text-center border-border/50 hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    {info.icon}
                  </div>
                  <CardTitle className="text-lg">{info.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  {info.details.map((detail, detailIndex) => (
                    <p key={detailIndex} className="text-muted-foreground mb-1">
                      {detail}
                    </p>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Форма обратной связи и карта */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Форма */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-2xl text-foreground">Напишите нам</CardTitle>
                <p className="text-muted-foreground">
                  Есть вопросы? Заполните форму, и мы обязательно ответим!
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Имя *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange("name", e.target.value)}
                        placeholder="Ваше имя"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Телефон</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+7 (999) 123-45-67"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="your@email.com"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="subject">Тема</Label>
                    <Input
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => handleInputChange("subject", e.target.value)}
                      placeholder="Тема сообщения"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message">Сообщение *</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => handleInputChange("message", e.target.value)}
                      placeholder="Ваше сообщение..."
                      rows={5}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                    <Send className="h-4 w-4 mr-2" />
                    Отправить сообщение
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Карта (заглушка) */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-2xl text-foreground">Как нас найти</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-secondary/20 h-80 rounded-lg flex items-center justify-center mb-6">
                  <div className="text-center text-muted-foreground">
                    <MapPin className="h-12 w-12 mx-auto mb-4 text-accent" />
                    <p>Москва, ул. Рыбацкая, 123</p>
                    <p className="text-sm mt-2">ТЦ "Рыболов", 2 этаж</p>
                  </div>
                </div>
                <div className="space-y-3 text-sm text-muted-foreground">
                  <p><strong>От метро Сокольники:</strong> автобус №32 до остановки "Рыбацкая"</p>
                  <p><strong>От метро ВДНХ:</strong> троллейбус №14 до остановки "ТЦ Рыболов"</p>
                  <p><strong>Парковка:</strong> бесплатная парковка на 50 мест</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Наши услуги */}
      <section className="py-16 bg-secondary/20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Наши услуги</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="text-center border-border/50 hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    {service.icon}
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ быстрые ответы */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Часто задаваемые вопросы</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg text-accent">Есть ли у вас доставка?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Да, мы доставляем по всей России. По Москве и области - в день заказа, 
                  по регионам от 2-3 дней.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg text-accent">Можно ли вернуть товар?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Да, возврат и обмен возможен в течение 14 дней при сохранении товарного вида 
                  и упаковки.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg text-accent">Есть ли скидки постоянным клиентам?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Да, у нас действует система скидок для постоянных покупателей до 15% 
                  в зависимости от суммы покупок.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg text-accent">Консультируете по выбору снастей?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Конечно! Наши консультанты - опытные рыболовы, которые помогут подобрать 
                  снаряжение под ваши задачи.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}