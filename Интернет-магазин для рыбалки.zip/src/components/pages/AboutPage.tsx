import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Calendar, Users, Award, MapPin } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

export function AboutPage() {
  const stats = [
    { icon: <Calendar className="h-6 w-6 text-accent" />, label: "Лет на рынке", value: "15+" },
    { icon: <Users className="h-6 w-6 text-accent" />, label: "Довольных клиентов", value: "10000+" },
    { icon: <Award className="h-6 w-6 text-accent" />, label: "Брендов", value: "50+" },
    { icon: <MapPin className="h-6 w-6 text-accent" />, label: "Городов доставки", value: "500+" }
  ];

  const team = [
    {
      name: "Михаил Петров",
      position: "Основатель и управляющий",
      experience: "25 лет рыболовного опыта",
      description: "Профессиональный рыболов, мастер спорта по рыболовному спорту"
    },
    {
      name: "Сергей Волков",
      position: "Эксперт по снастям",
      experience: "15 лет в рыболовной индустрии",
      description: "Специалист по выбору удилищ и катушек, инструктор по спиннингу"
    },
    {
      name: "Алексей Рыбин",
      position: "Консультант по приманкам",
      experience: "12 лет практического опыта",
      description: "Эксперт по воблерам и силиконовым приманкам, участник соревнований"
    }
  ];

  const values = [
    {
      title: "Качество",
      description: "Мы работаем только с проверенными производителями и гарантируем качество каждого товара."
    },
    {
      title: "Экспертность",
      description: "Наша команда - это опытные рыболовы, которые знают всё о снастях из первых рук."
    },
    {
      title: "Сервис",
      description: "Индивидуальный подход к каждому клиенту и профессиональные консультации."
    },
    {
      title: "Доступность",
      description: "Справедливые цены и удобные условия доставки по всей России."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Заголовок */}
      <section className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">О магазине МЕДВЕДЪ</h1>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            История успеха, построенная на любви к рыбалке и стремлении предоставить 
            рыболовам только лучшее снаряжение
          </p>
        </div>
      </section>

      {/* Наша история */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-foreground">Наша история</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Магазин "МЕДВЕДЪ" был основан в 2009 году группой энтузиастов-рыболовов, 
                  которые понимали, насколько важно качественное снаряжение для успешной рыбалки.
                </p>
                <p>
                  Начав с небольшого магазина в центре Москвы, мы постепенно расширяли 
                  ассортимент и географию присутствия. Сегодня мы один из ведущих 
                  рыболовных магазинов России.
                </p>
                <p>
                  Наша миссия остается неизменной: помочь каждому рыболову найти 
                  идеальное снаряжение для своего стиля ловли и получить максимальное 
                  удовольствие от любимого хобби.
                </p>
              </div>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1706443256843-121b4646816c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwc3RvcmUlMjBpbnRlcmlvcnxlbnwxfHx8fDE3NTgyODI1NzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Магазин МЕДВЕДЪ"
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Статистика */}
      <section className="py-16 bg-secondary/20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Наши достижения</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center border-border/50">
                <CardContent className="p-6">
                  <div className="flex justify-center mb-4">
                    {stat.icon}
                  </div>
                  <div className="text-2xl font-bold text-foreground mb-2">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Наши ценности */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Наши ценности</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="border-border/50 hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg text-center text-accent">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-center">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Команда */}
      <section className="py-16 bg-muted/10">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Наша команда</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="border-border/50">
                <CardHeader className="text-center">
                  <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-accent/10 flex items-center justify-center">
                    <Users className="h-12 w-12 text-accent" />
                  </div>
                  <CardTitle className="text-foreground">{member.name}</CardTitle>
                  <Badge variant="secondary" className="w-fit mx-auto">
                    {member.position}
                  </Badge>
                </CardHeader>
                <CardContent className="text-center space-y-2">
                  <p className="font-medium text-muted-foreground">{member.experience}</p>
                  <p className="text-sm text-muted-foreground">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}