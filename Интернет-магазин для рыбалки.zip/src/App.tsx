import { useState } from "react";
import { Header } from "./components/Header";
import { HomePage } from "./components/pages/HomePage";
import { CatalogPage } from "./components/pages/CatalogPage";
import { AboutPage } from "./components/pages/AboutPage";
import { TipsPage } from "./components/pages/TipsPage";
import { ContactPage } from "./components/pages/ContactPage";
import { Cart } from "./components/Cart";
import { CheckoutForm } from "./components/CheckoutForm";
import { Footer } from "./components/Footer";
import { Toaster } from "./components/ui/sonner";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  inStock: boolean;
}

interface CartItem {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

// Товары для рыбалки
const products: Product[] = [
  {
    id: 1,
    name: "Спиннинг профессиональный Carbon Pro",
    description: "Высококачественное углеволоконное удилище для спиннинговой ловли. Длина 2.4м, тест 10-30г.",
    price: 8500,
    category: "Удилища",
    image: "https://images.unsplash.com/photo-1572726243931-884b05e4a198?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwcm9kJTIwZXF1aXBtZW50fGVufDF8fHx8MTc1ODIwMTY3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    inStock: true
  },
  {
    id: 2,
    name: "Катушка безынерционная Shimano",
    description: "Надёжная безынерционная катушка с плавным ходом и точной настройкой фрикциона.",
    price: 12000,
    category: "Катушки",
    image: "https://images.unsplash.com/photo-1661944499262-8f19514ec416?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwcmVlbCUyMHRhY2tsZXxlbnwxfHx8fDE3NTgyODIwMzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    inStock: true
  },
  {
    id: 3,
    name: "Набор приманок Mega Mix",
    description: "Разнообразный набор воблеров, блёсен и силиконовых приманок для различных условий ловли.",
    price: 3500,
    category: "Приманки",
    image: "https://images.unsplash.com/photo-1586920917141-71ffe0798441?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwbHVyZXMlMjBiYWl0c3xlbnwxfHx8fDE3NTgyODIwMzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    inStock: true
  },
  {
    id: 4,
    name: "Подсачек складной Professional",
    description: "Прочный складной подсачек с резиновой сеткой. Удобен в транспортировке.",
    price: 2800,
    category: "Аксессуары",
    image: "https://images.unsplash.com/photo-1643636372526-7d687fb202a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwbmV0JTIwZXF1aXBtZW50fGVufDF8fHx8MTc1ODI4MjAzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    inStock: true
  },
  {
    id: 5,
    name: "Ящик для снастей Multi Box",
    description: "Многосекционный ящик для хранения и транспортировки рыболовных принадлежностей.",
    price: 4200,
    category: "Аксессуары",
    image: "https://images.unsplash.com/photo-1586920917141-71ffe0798441?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwdGFja2xlJTIwYm94fGVufDF8fHx8MTc1ODIyMzk3MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    inStock: false
  },
  {
    id: 6,
    name: "Вадерсы неопреновые Aqua Pro",
    description: "Качественные неопреновые вадерсы для комфортной рыбалки в холодной воде.",
    price: 15000,
    category: "Одежда",
    image: "https://images.unsplash.com/photo-1584753139103-2f2c5bf44d08?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwYm9vdHMlMjB3YWRlcnN8ZW58MXx8fHwxNzU4MjgyMDM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    inStock: true
  },
  {
    id: 7,
    name: "Поплавочное удилище Match Master",
    description: "Телескопическое поплавочное удилище для ловли мирной рыбы. Длина 4м.",
    price: 5500,
    category: "Удилища",
    image: "https://images.unsplash.com/photo-1572726243931-884b05e4a198?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwcm9kJTIwZXF1aXBtZW50fGVufDF8fHx8MTc1ODIwMTY3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    inStock: true
  },
  {
    id: 8,
    name: "Мультипликаторная катушка Bass Pro",
    description: "Профессиональная мультипликаторная катушка для ловли хищной рыбы.",
    price: 18500,
    category: "Катушки",
    image: "https://images.unsplash.com/photo-1661944499262-8f19514ec416?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXNoaW5nJTIwcmVlbCUyMHRhY2tsZXxlbnwxfHx8fDE3NTgyODIwMzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    inStock: true
  }
];

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);

  const addToCart = (product: Product) => {
    setCartItems(prev => {
      const existingItem = prev.find(item => item.id === product.id);
      if (existingItem) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, {
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        quantity: 1
      }];
    });
  };

  const updateQuantity = (id: number, quantity: number) => {
    if (quantity === 0) {
      removeFromCart(id);
      return;
    }
    setCartItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (id: number) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const cartItemsCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = () => {
    setShowCart(false);
    setShowCheckout(true);
  };

  const handleOrderComplete = () => {
    setCartItems([]);
    setShowCheckout(false);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'catalog':
        return <CatalogPage products={products} onAddToCart={addToCart} />;
      case 'about':
        return <AboutPage />;
      case 'tips':
        return <TipsPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        cartItemsCount={cartItemsCount} 
        onCartClick={() => setShowCart(true)}
        currentPage={currentPage}
        onNavigate={setCurrentPage}
      />
      <main>
        {renderCurrentPage()}
      </main>
      <Footer />

      {showCart && (
        <Cart
          items={cartItems}
          onUpdateQuantity={updateQuantity}
          onRemoveItem={removeFromCart}
          onClose={() => setShowCart(false)}
          onCheckout={handleCheckout}
        />
      )}

      {showCheckout && (
        <CheckoutForm
          items={cartItems}
          total={cartTotal}
          onClose={() => setShowCheckout(false)}
          onOrderComplete={handleOrderComplete}
        />
      )}

      <Toaster />
    </div>
  );
}